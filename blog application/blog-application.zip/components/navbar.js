const navbar = () => {
  return `
      <div id="navbar">
      <h3>
        <a href="../pages/index.html">All Posts</a>
        <a href="../pages/search.html">Search post</a>
      </h3>
      <h3>
        <a href="../pages/create.html">create blog</a>
      </h3>
    </div>
    `;
};

export default navbar;
