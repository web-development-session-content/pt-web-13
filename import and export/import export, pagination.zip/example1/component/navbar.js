function navbar() {
  return `<div id="navbar">
       <h3>
         <a href="index.html">Home</a>
       </h3>
       <div id="options">
         <h3>
           <a href="cart.html">cart</a>
         </h3>
         <h3>
           <a href="payment.html">payment</a>
         </h3>
       </div>
     </div>`;
}

export default navbar;
